#!/usr/bin/env python3
import sys

current = None
positive = 0
total = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")

    if current != key:
        if current is not None:
            percentage = (positive / total) * 100 if total else 0
            print(f"{current}\t{percentage:.2f}%")
        current = key
        positive = 0
        total = 0

    if value == "POSITIVE":
        positive += 1
    total += 1

if current is not None:
    percentage = (positive / total) * 100 if total else 0
    print(f"{current}\t{percentage:.2f}%")
