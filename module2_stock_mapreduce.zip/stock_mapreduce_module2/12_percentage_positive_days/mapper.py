#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    open_price = row.get("Open", "").strip()
    close = row.get("Close", "").strip()

    if symbol and open_price and close:
        o = float(open_price)
        c = float(close)
        result = "POSITIVE" if c > o else "NEGATIVE" if c < o else "UNCHANGED"
        print(f"{symbol}\t{result}")
