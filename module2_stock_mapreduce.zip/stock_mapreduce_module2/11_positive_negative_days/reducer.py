#!/usr/bin/env python3
import sys

current = None
positive = 0
negative = 0
unchanged = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")

    if current != key:
        if current is not None:
            print(f"{current}\tPositive={positive}\tNegative={negative}\tUnchanged={unchanged}")
        current = key
        positive = negative = unchanged = 0

    if value == "POSITIVE":
        positive += 1
    elif value == "NEGATIVE":
        negative += 1
    else:
        unchanged += 1

if current is not None:
    print(f"{current}\tPositive={positive}\tNegative={negative}\tUnchanged={unchanged}")
