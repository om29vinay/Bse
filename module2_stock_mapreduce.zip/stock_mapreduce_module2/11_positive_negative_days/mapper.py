#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    open_price = row.get("Open", "").strip()
    close = row.get("Close", "").strip()

    if symbol and open_price and close:
        o = float(open_price)
        c = float(close)

        if c > o:
            result = "POSITIVE"
        elif c < o:
            result = "NEGATIVE"
        else:
            result = "UNCHANGED"

        print(f"{symbol}\t{result}")
