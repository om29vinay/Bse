Module 2 - Stock MapReduce Assignment

Input file:
    combined_stock_data.csv

CSV columns:
    Date, Symbol, Open, High, Low, Close, Volume

Each numbered folder contains:
    mapper.py
    reducer.py

Queries covered:
1. Count total number of stock records
2. Count records per stock
3. Total trading volume per stock
4. Average closing price per stock
5. Average opening price per stock
6. Number of trading days per stock
7. Total trading days
8. Average volume per stock
9. Highest and lowest price per stock
10. Average trading range per stock
11. Positive, negative and unchanged trading days per stock
12. Percentage of positive days per stock
13. Overall return percentage per stock

Important:
- Mapper input is the CSV file through Hadoop Streaming stdin.
- Reducer expects Hadoop Streaming's sorted mapper output.
- For overall return %, the calculation used is:
      ((last Close - first Open) / first Open) * 100
  The supplied CSV is chronologically ordered, so the reducer keeps the
  first and last records for each Symbol.
- Positive day = Close > Open
- Negative day = Close < Open
- Unchanged day = Close == Open
- Trading range = High - Low
