#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    open_price = row.get("Open", "").strip()
    if symbol and open_price:
        print(f"{symbol}\t{open_price}")
