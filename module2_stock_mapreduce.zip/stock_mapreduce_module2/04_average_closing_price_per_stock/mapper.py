#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    close = row.get("Close", "").strip()
    if symbol and close:
        print(f"{symbol}\t{close}")
