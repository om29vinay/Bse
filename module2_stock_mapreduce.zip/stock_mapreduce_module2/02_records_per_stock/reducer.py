#!/usr/bin/env python3
import sys

current = None
total = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")
    value = int(value)

    if current != key:
        if current is not None:
            print(f"{current}\t{total}")
        current = key
        total = 0

    total += value

if current is not None:
    print(f"{current}\t{total}")
