#!/usr/bin/env python3
import sys

current = None
dates = set()

for line in sys.stdin:
    key, date = line.rstrip("\n").split("\t")

    if current != key:
        if current is not None:
            print(f"{current}\t{len(dates)}")
        current = key
        dates = set()

    dates.add(date)

if current is not None:
    print(f"{current}\t{len(dates)}")
