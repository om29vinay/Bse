#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    date = row.get("Date", "").strip()
    if symbol and date:
        print(f"{symbol}\t{date}")
