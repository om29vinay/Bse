#!/usr/bin/env python3
import sys

current = None
highest = float("-inf")
lowest = float("inf")

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")
    high, low = map(float, value.split(","))

    if current != key:
        if current is not None:
            print(f"{current}\tHighest={highest:.2f}\tLowest={lowest:.2f}")
        current = key
        highest = float("-inf")
        lowest = float("inf")

    highest = max(highest, high)
    lowest = min(lowest, low)

if current is not None:
    print(f"{current}\tHighest={highest:.2f}\tLowest={lowest:.2f}")
