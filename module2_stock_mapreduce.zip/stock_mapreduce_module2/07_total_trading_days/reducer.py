#!/usr/bin/env python3
import sys

dates = set()

for line in sys.stdin:
    key, date = line.rstrip("\n").split("\t")
    dates.add(date)

print(f"Total Trading Days\t{len(dates)}")
