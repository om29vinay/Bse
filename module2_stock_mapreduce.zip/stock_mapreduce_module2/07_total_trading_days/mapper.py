#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    date = row.get("Date", "").strip()
    if date:
        print(f"TOTAL_DAYS\t{date}")
