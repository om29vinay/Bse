#!/usr/bin/env python3
import sys

current = None
total = 0
count = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")
    value = int(float(value))

    if current != key:
        if current is not None:
            print(f"{current}\t{total / count:.2f}")
        current = key
        total = 0
        count = 0

    total += value
    count += 1

if current is not None:
    print(f"{current}\t{total / count:.2f}")
