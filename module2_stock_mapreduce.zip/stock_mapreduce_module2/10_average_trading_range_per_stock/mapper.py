#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    high = row.get("High", "").strip()
    low = row.get("Low", "").strip()
    if symbol and high and low:
        trading_range = float(high) - float(low)
        print(f"{symbol}\t{trading_range}")
