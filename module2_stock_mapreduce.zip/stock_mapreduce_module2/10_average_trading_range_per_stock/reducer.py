#!/usr/bin/env python3
import sys

current = None
total_range = 0.0
count = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")
    value = float(value)

    if current != key:
        if current is not None:
            print(f"{current}\t{total_range / count:.2f}")
        current = key
        total_range = 0.0
        count = 0

    total_range += value
    count += 1

if current is not None:
    print(f"{current}\t{total_range / count:.2f}")
