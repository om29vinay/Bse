#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    if row.get("Symbol"):
        print("TOTAL\t1")
