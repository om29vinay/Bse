#!/usr/bin/env python3
import sys

current = None
first_date = None
first_open = None
last_date = None
last_close = None

def output():
    if current is not None and first_open not in (None, 0):
        ret = ((last_close - first_open) / first_open) * 100
        print(f"{current}\t{ret:.2f}%")

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")
    date, open_price, close = value.split(",")
    open_price = float(open_price)
    close = float(close)

    if current != key:
        output()
        current = key
        first_date = date
        first_open = open_price
        last_date = date
        last_close = close
    else:
        # Hadoop Streaming sorts by key first, then by the complete value.
        # This reducer therefore assumes input dates are already chronological
        # within each Symbol, as in the supplied combined_stock_data.csv.
        last_date = date
        last_close = close

output()
