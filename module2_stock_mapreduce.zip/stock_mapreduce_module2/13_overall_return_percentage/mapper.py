#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    date = row.get("Date", "").strip()
    open_price = row.get("Open", "").strip()
    close = row.get("Close", "").strip()

    if symbol and date and open_price and close:
        print(f"{symbol}\t{date},{open_price},{close}")
