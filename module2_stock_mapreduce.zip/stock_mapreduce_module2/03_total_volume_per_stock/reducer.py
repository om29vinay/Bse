#!/usr/bin/env python3
import sys

current = None
total_volume = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t")
    value = int(float(value))

    if current != key:
        if current is not None:
            print(f"{current}\t{total_volume}")
        current = key
        total_volume = 0

    total_volume += value

if current is not None:
    print(f"{current}\t{total_volume}")
