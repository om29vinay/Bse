#!/usr/bin/env python3
import sys, csv

reader = csv.DictReader(sys.stdin)
for row in reader:
    symbol = row.get("Symbol", "").strip()
    volume = row.get("Volume", "").strip()
    if symbol and volume:
        print(f"{symbol}\t{volume}")
