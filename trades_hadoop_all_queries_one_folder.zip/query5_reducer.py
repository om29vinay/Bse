#!/usr/bin/env python3
import sys

broker_counts = {}

for line in sys.stdin:
    broker, value = line.rstrip("\n").split("\t", 1)
    broker_counts[broker] = broker_counts.get(broker, 0) + int(value)

if broker_counts:
    broker, count = max(broker_counts.items(), key=lambda x: (x[1], x[0]))
    print(f"Most Active Broker\t{broker}\t{count}")
