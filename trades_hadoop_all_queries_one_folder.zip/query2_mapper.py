#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0].strip().lower() == "tradeid":
        continue
    transaction_type = row[4].strip().upper()
    if transaction_type in ("BUY", "SELL"):
        print(f"{transaction_type}\t1")
