#!/usr/bin/env python3
import sys

total = 0
for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t", 1)
    total += int(value)

print(f"Total Trades\t{total}")
