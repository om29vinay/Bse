#!/usr/bin/env python3
import sys

current_id = None
current_name = None
total_value = 0.0

for line in sys.stdin:
    parts = line.rstrip("\n").split("\t")
    customer_id = parts[0]
    customer_name = parts[1]
    value = float(parts[2])

    if current_id is not None and customer_id != current_id:
        print(f"{current_id}\t{current_name}\t{total_value:.2f}")
        total_value = 0.0

    current_id = customer_id
    current_name = customer_name
    total_value += value

if current_id is not None:
    print(f"{current_id}\t{current_name}\t{total_value:.2f}")
