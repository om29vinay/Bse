#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0].strip().lower() == "tradeid":
        continue
    transaction_type = row[4].strip().upper()
    if transaction_type == "BUY":
        customer_id = row[1].strip()
        customer_name = row[2].strip()
        quantity = int(row[5])
        print(f"{customer_id}\t{customer_name}\t{quantity}")
