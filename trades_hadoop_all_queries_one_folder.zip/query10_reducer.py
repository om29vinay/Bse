#!/usr/bin/env python3
import sys

current_id = None
current_name = None
stocks = set()

def output():
    if current_id is not None and len(stocks) > 3:
        print(f"{current_id}\t{current_name}\tdifferent_stocks={len(stocks)}")

for line in sys.stdin:
    parts = line.rstrip("\n").split("\t")
    customer_id = parts[0]
    customer_name = parts[1]
    stock = parts[2]

    if current_id is not None and customer_id != current_id:
        output()
        stocks = set()

    current_id = customer_id
    current_name = customer_name
    stocks.add(stock)

output()
