#!/usr/bin/env python3
import sys

current_id = None
current_name = None
total_bought = 0

for line in sys.stdin:
    parts = line.rstrip("\n").split("\t")
    customer_id = parts[0]
    customer_name = parts[1]
    quantity = int(parts[2])

    if current_id is not None and customer_id != current_id:
        if total_bought > 500:
            print(f"{current_id}\t{current_name}\tBUY shares={total_bought}")
        total_bought = 0

    current_id = customer_id
    current_name = customer_name
    total_bought += quantity

if current_id is not None and total_bought > 500:
    print(f"{current_id}\t{current_name}\tBUY shares={total_bought}")
