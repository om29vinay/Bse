#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0].strip().lower() == "tradeid":
        continue
    trade_id = row[0].strip()
    customer_id = row[1].strip()
    stock = row[3].strip()
    quantity = int(row[5])
    price = float(row[6])
    print(f"max\t{price}\t{trade_id}\t{customer_id}\t{stock}\t{quantity}")
