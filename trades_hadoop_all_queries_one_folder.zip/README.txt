Hadoop Streaming - All 10 Queries

All mapper.py and reducer.py files are in this single folder.

Files:
query1_mapper.py / query1_reducer.py
query2_mapper.py / query2_reducer.py
query3_mapper.py / query3_reducer.py
query4_mapper.py / query4_reducer.py
query5_mapper.py / query5_reducer.py
query6_mapper.py / query6_reducer.py
query7_mapper.py / query7_reducer.py
query8_mapper.py / query8_reducer.py
query9_mapper.py / query9_reducer.py
query10_mapper.py / query10_reducer.py

Use the mapper and reducer pair corresponding to each query.
