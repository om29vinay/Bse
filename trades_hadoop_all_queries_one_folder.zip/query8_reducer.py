#!/usr/bin/env python3
import sys

counts = {}

for line in sys.stdin:
    date, value = line.rstrip("\n").split("\t", 1)
    counts[date] = counts.get(date, 0) + int(value)

if counts:
    date, count = max(counts.items(), key=lambda x: (x[1], x[0]))
    print(f"Busiest Trading Day\t{date}\t{count} trades")
