#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0].strip().lower() == "tradeid":
        continue
    trade_date = row[7].strip()
    print(f"{trade_date}\t1")
