#!/usr/bin/env python3
import sys

current_key = None
total_quantity = 0

for line in sys.stdin:
    key, value = line.rstrip("\n").split("\t", 1)
    value = int(value)

    if current_key is not None and key != current_key:
        print(f"{current_key}\t{total_quantity}")
        total_quantity = 0

    current_key = key
    total_quantity += value

if current_key is not None:
    print(f"{current_key}\t{total_quantity}")
