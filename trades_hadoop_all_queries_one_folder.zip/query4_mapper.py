#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0].strip().lower() == "tradeid":
        continue
    customer_id = row[1].strip()
    customer_name = row[2].strip()
    quantity = int(row[5])
    price = float(row[6])
    trade_value = quantity * price
    print(f"{customer_id}\t{customer_name}\t{trade_value}")
