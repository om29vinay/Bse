#!/usr/bin/env python3
import sys

best = None

for line in sys.stdin:
    parts = line.rstrip("\n").split("\t")
    price = float(parts[1])

    if best is None or price > best[0]:
        best = (price, parts[2], parts[3], parts[4], parts[5])

if best:
    price, trade_id, customer_id, stock, quantity = best
    print(f"Highest Priced Trade\tTradeID={trade_id}\tCustomerID={customer_id}\tStock={stock}\tQuantity={quantity}\tPrice={price:.2f}")
