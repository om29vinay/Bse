#!/usr/bin/env python3
import sys
import csv

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0].strip().lower() == "tradeid":
        continue
    stock = row[3].strip()
    quantity = int(row[5])
    print(f"{stock}\t{quantity}")
