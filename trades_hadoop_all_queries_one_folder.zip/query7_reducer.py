#!/usr/bin/env python3
import sys

best = None

for line in sys.stdin:
    parts = line.rstrip("\n").split("\t")
    trade_value = float(parts[1])

    if best is None or trade_value > best[0]:
        best = (trade_value, parts[2], parts[3], parts[4], parts[5], parts[6])

if best:
    value, trade_id, customer_id, stock, quantity, price = best
    print(f"Highest Value Trade\tTradeID={trade_id}\tCustomerID={customer_id}\tStock={stock}\tQuantity={quantity}\tPrice={float(price):.2f}\tTradeValue={value:.2f}")
