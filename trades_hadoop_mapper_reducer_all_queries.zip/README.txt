HADOOP STREAMING - TRADES.CSV
================================

Input columns:
TradeID, CustomerID, CustomerName, Stock, TransactionType, Quantity, Price, TradeDate, Broker

Queries included:
1. Count total trades
2. Count BUY and SELL transactions
3. Total quantity per stock
4. Total trade value per customer (Quantity * Price)
5. Most active broker
6. Highest priced trade
7. Highest-value trade (Quantity * Price)
8. Busiest trading day
9. Customers who bought more than 500 shares
10. Customers who traded more than 3 different stocks

Windows / Hadoop Streaming example:
hadoop jar %HADOOP_HOME%\share\hadoop\tools\lib\hadoop-streaming-*.jar ^
-input /trades.csv ^
-output /output/query1 ^
-mapper query1_count_total_trades/mapper.py ^
-reducer query1_count_total_trades/reducer.py ^
-file query1_count_total_trades/mapper.py ^
-file query1_count_total_trades/reducer.py

For each query, change the input/output and mapper/reducer folder.

Linux example:
hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-*.jar \
-input /trades.csv \
-output /output/query1 \
-mapper query1_count_total_trades/mapper.py \
-reducer query1_count_total_trades/reducer.py \
-file query1_count_total_trades/mapper.py \
-file query1_count_total_trades/reducer.py

Important:
- These scripts are designed for Hadoop Streaming.
- The mapper skips the CSV header.
- CSV is parsed using Python's csv module.
- Query 9 uses BUY transactions only.
- Query 10 counts distinct stocks per customer.
